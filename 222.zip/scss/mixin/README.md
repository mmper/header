## 方法

1. ellipsis 文字省略
2. flex 浏览器兼容
3. transform 兼容



@include flex();
@include flex-align-center();
@include flex-pack-center();
@include flex-pack-justify();
@include flex-pack-start();
@include flex-pack-end();
@include flex-1();
@include flex-v();
@include flex-h();
@include flex-align-start();
@include flex-align-end();
